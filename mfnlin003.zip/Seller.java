import java.util.Scanner;

     
     public class Seller{
          
            public  String ID;
            public  String name;
            public String location;
            public String product;
            public  Money unit_price;
            public   int    number_of_units;
           
            
        /**    public Seller(String id, String name, String location , String product, Money unitprice, int num ){
                    
                    this.ID=id;
                    this.name=name;
                    this.location=location;
                    this.product=product;
                    this.unit_price=unitprice;
                    this.number_of_units=num;
                    
            }        
          **/  
            public String toString(){
            
                  return "ID of the seller: "+ this.ID +"\n"+"Name of the seller: "+ this.name +"\n"+ "Location of the seller: "+ this.location +"\n"+ "The product to sell: "+ this.product + "\n"+ "Product unit price: "+ this.unit_price +"\n" +"The number of available units: "+ this.number_of_units;
            
            }
     }      