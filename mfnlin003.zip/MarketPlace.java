import java.io.*;
import java.util.Scanner;
import java.util.*;
      
      public class MarketPlace {
      
             public static void main(String[] args){
             
                     System.out.println("Enter the name of a "+"\"Comma Separated Values\""+ " (CSV) file:");
                     Scanner keyboard = new Scanner(System.in);
                     String filename = keyboard.nextLine();
                     File file = new File(filename);
                     try {
                          FileReader a = new FileReader(file);
                          BufferedReader reader =  new BufferedReader(a); 
                          
                          String x;
                          
                          String line = reader.readLine();
                          if (line == null){
                           System.out.println("The file contains no seller data.");
                           System.exit(0);
                           }

                          int length= Integer.parseInt(line);
                          
                          Seller array[] = new Seller[length];
                          Currency c = new Currency("R", "ZAR", 100);
                     
                          int counter = 0;
                          if (length==0){
                              System.out.println("The file contains no seller data.");
                          } 
                          else{
                         
                              
                              while ((x = reader.readLine())!= null) {
                                array[counter] = new Seller();
                                String read[]= x.split(",");
                                if(!( read.equals(line))){
                                   array[counter].ID= read[0];
                                   array[counter].name=read[1];
                                   array[counter].location=read[2];
                                   array[counter].product=read[3].trim();
                                   array[counter].unit_price = new Money(read[4], c);
                                   array[counter].number_of_units = Integer.parseInt(read[5].trim());
                                   counter= counter+1;
                                }
                               else{System.out.println("The file contains no seller data.");} 
                             }    
                             reader.close();                
                            System.out.println("Enter the name of a product:");
                            String product = keyboard.nextLine();
                            System.out.println("Enter the number of units required:");
                            int n = Integer.parseInt(keyboard.next());
                            System.out.println("Enter the maximum unit price:");
                            String price= keyboard.next();
                            Currency rand = new Currency("R", "ZAR", 100);
                            Money  Price= new Money (price, c);
                            int len= array.length;
                            int flag= 0;
                            for (int index = 0 ;  index < len ; index++){
                       
                        
                                if (((array[index].product).equals(product)) &&((array[index].number_of_units) >= n) &&((Price.compareTo((array[index].unit_price))==0)||((Price.compareTo((array[index].unit_price))>0)))) {
                                     System.out.print((array[index].ID)+ " :");
                                     System.out.print((array[index].name)+ " in");
                                     System.out.print((array[index].location)+" has ");
                                     System.out.print((array[index].number_of_units)+" ");
                                     System.out.print( (array[index].product));
                                     System.out.print(" for "+ (array[index].unit_price)+" each."+"\n");
                                     flag=1;
                                }
                            }
                            if (flag==0){
                               System.out.println("None found.");
                            }   
                        } 
                      
                      
                      }  
                      catch(FileNotFoundException ex){
                            System.out.println("The file contains no seller data.");
                      }
                      catch(IOException ex){}
                  }   
                        
            }
         
                     
              
         