import java.util.Scanner;
import java.util.Locale;
import java.text.NumberFormat;

      public class TestSeller{
      
            public static void main(String[] args){
                               
                  System.out.println("Please enter the details of the seller");
                  Scanner keyboard = new Scanner(System.in);
                  System.out.print("ID: ");
                  String id = keyboard.nextLine();
                  System.out.print("Name: ");
                  String name = keyboard.nextLine();
                  System.out.print("Location: ");
                  String loc= keyboard.nextLine();
                  System.out.print("Product: ");
                  String product= keyboard.nextLine();
                  System.out.print("Price: ");
                  String price= keyboard.nextLine();
                  System.out.print("Units: ");
                  int num = Integer.parseInt(keyboard.nextLine());
                  
                  Currency rand = new Currency("R", "ZAR", 100);
                  Money Price= new Money(price,rand);
                  Seller ob = new Seller();
                  ob.ID= id;
                  ob.name= name;
                  ob.location=loc;
                  ob.product=product;
                  ob.unit_price= Price;
                  ob.number_of_units= num;
                  System.out.println("The seller has successfully created:");
                  System.out.println(ob.toString());
                 
               }
               
        }       